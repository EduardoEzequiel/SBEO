<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToReservaTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('reserva', function(Blueprint $table)
		{
			$table->foreign('usuario_id', 'fk_1_reserva')->references('id')->on('usuario')->onUpdate('CASCADE')->onDelete('RESTRICT');
			$table->foreign('livro_id', 'fk_2_reserva')->references('id')->on('livro')->onUpdate('CASCADE')->onDelete('RESTRICT');
			$table->foreign('aluno_id', 'fk_3_reserva')->references('id')->on('aluno')->onUpdate('CASCADE')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('reserva', function(Blueprint $table)
		{
			$table->dropForeign('fk_1_reserva');
			$table->dropForeign('fk_2_reserva');
			$table->dropForeign('fk_3_reserva');
		});
	}

}
