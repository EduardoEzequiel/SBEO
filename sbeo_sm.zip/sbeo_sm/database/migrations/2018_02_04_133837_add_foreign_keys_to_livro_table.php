<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToLivroTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('livro', function(Blueprint $table)
		{
			$table->foreign('editora_id', 'fk_2_livro')->references('id')->on('editora')->onUpdate('CASCADE')->onDelete('RESTRICT');
			$table->foreign('genero_id', 'fk_3_livro')->references('id')->on('genero')->onUpdate('CASCADE')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('livro', function(Blueprint $table)
		{
			$table->dropForeign('fk_2_livro');
			$table->dropForeign('fk_3_livro');
		});
	}

}
