<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateLivroTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('livro', function(Blueprint $table)
		{
			$table->bigInteger('id', true);
			$table->string('nome', 256)->nullable();
			$table->string('numeracao', 256)->nullable();
			$table->string('status', 10)->nullable();
			$table->integer('ano')->nullable();
			$table->string('ISBN', 256)->nullable();
			$table->string('disponibilidade', 256)->nullable();
			$table->string('localizacao', 256)->nullable();
			$table->string('situacao', 256)->nullable();
			$table->string('volume', 256)->nullable();
			$table->string('tipo', 1)->nullable();
			$table->bigInteger('genero_id')->nullable()->index('fk_3_livro');
			$table->bigInteger('editora_id')->nullable()->index('fk_2_livro');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('livro');
	}

}
