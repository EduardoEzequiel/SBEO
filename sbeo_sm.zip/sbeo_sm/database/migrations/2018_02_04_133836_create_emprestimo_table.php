<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEmprestimoTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('emprestimo', function(Blueprint $table)
		{
			$table->bigInteger('id', true);
			$table->date('dt_emprestimo')->nullable();
			$table->date('dt_devolucao')->nullable();
			$table->bigInteger('livro_id')->nullable()->index('fk_2_emprestimo');
			$table->bigInteger('usuario_id')->nullable()->index('fk_1_emprestimo');
			$table->bigInteger('aluno_id')->nullable()->index('fk_3_emprestimo');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('emprestimo');
	}

}
