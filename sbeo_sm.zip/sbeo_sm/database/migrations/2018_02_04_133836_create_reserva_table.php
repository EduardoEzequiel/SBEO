<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateReservaTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('reserva', function(Blueprint $table)
		{
			$table->bigInteger('id', true);
			$table->date('dt_reserva')->nullable();
			$table->date('dt_baixa')->nullable();
			$table->bigInteger('livro_id')->nullable()->index('fk_2_reserva');
			$table->bigInteger('aluno_id')->nullable()->index('fk_3_reserva');
			$table->bigInteger('usuario_id')->nullable()->index('fk_1_reserva');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('reserva');
	}

}
