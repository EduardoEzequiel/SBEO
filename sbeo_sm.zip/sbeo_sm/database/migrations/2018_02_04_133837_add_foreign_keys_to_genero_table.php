<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToGeneroTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('genero', function(Blueprint $table)
		{
			$table->foreign('subgenero_id', 'fk_1_genero')->references('id')->on('subgenero')->onUpdate('CASCADE')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('genero', function(Blueprint $table)
		{
			$table->dropForeign('fk_1_genero');
		});
	}

}
