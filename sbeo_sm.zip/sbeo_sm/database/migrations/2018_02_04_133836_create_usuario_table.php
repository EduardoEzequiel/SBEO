<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateUsuarioTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('usuario', function(Blueprint $table)
		{
			$table->bigInteger('id', true);
			$table->string('nome', 256)->nullable();
			$table->string('matricula', 128)->nullable();
		    $table->string('login', 128)->nullable()->unique('login');
			$table->string('senha', 256)->nullable();
			$table->string('perfil')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('usuario');
	}

}
