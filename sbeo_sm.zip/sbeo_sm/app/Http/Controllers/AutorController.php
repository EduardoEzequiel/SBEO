<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Autor;
use App\Livro;
use App\Http\Requests\AutorRequest;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Controller;
use App\User;

class AutorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       
        $registros = Autor::all();
        return view('autor.index', compact('registros'));
    }


    public function cadastrar()
    {
            return view('autor.cadastrar');

    }  
    /**
     * Show the form for search.
     *
     * @return \Illuminate\Http\Response
     */
    public function search()
    {
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

       
        $camposValidados = $request->validate([
            'nome' => 'required' 
          

        ]);
        
        $autor = Autor::create($camposValidados);
        return redirect()->to('autor'); 
    }
    


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editar($id)
    {
       
        
        $registro = Autor::where('id', '=', $id)->first();
        return view('autor.editar', compact('registro'));
        
    }

    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $camposValidados = $request->validate([
            'nome' => 'required',

        ]);

        $autor = Autor::find($id);
        $autor->fill($camposValidados);
        $autor->save();

        return redirect()->to('autor');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $autor = Autor::withCount('livros')->find($id);
       
        if ($autor->livros_count > 0) {
            $msgLivro = "Não é possível deletar o Autor! Deve está relacionada a um Livro verifique por favor.";

            return redirect()->to('autor')->with('erro', $msgLivro);
        }

        $autor->delete();
        return redirect()->to('autor')->with('sucesso', 'Autor excluído com sucesso!');
    }

}
        /*
        $autor = Autor::find($id);
        $autor->delete();
        $registros = Autor::all();
        return view('autor.index', compact('registros'));
    }
}
*/