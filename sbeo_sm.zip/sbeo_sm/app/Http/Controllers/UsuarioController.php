<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Usuario;
use App\Reserva;
use App\Emprestimo;
use App\Http\Requests\UsuariosRequest;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\Rule;
class UsuarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $registros = Usuario::all();
        return view('usuario.index', compact('registros'));
    }

    public function cadastrar()
    {
            return view('usuario.cadastrar');

    } 

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $camposValidados = $request->validate([
            'nome' => 'required',
            'matricula'  => 'required|unique:usuario', 
            'login' => 'required|unique:usuario',
            'perfil'  => 'required', 

        ]);
        if($request->get('password')) {
            $camposValidados['password'] = bcrypt($request->get('password'));
        }
                
        $usuario = Usuario::create($camposValidados);
        return redirect()->to('usuario'); 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editar($id)
    {   
        $registro = Usuario::where('id', '=', $id)->first();
        return view('usuario.editar', compact('registro'));
            
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $unique = Rule::unique('usuario')->ignore($id);
        
        $camposValidados = $request->validate([
            'nome' => 'required',
            'matricula'  => ['required', $unique], 
            'login' =>  ['required', $unique],
            'password' => 'required',
            'perfil'  => 'required', 
            

        ]);
        $camposValidados['password'] = bcrypt($request->get('password'));
        $usuario = Usuario::find($id);
        $usuario->fill($camposValidados);
        $usuario->save();
        
        return redirect()->to('usuario');
    }
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      
        $msgEmprestimo = "";
        $msgReserva = "";
        
      

        if (Emprestimo::where('usuario_id', '=', $id)->count()) {
            $msgEmprestimo = "Não é possível deletar o Usuario ! Deve está relacionada a uma Reserva ou Emprestimo verifique por favor.";
        }

        if (Reserva::where('usuario_id', '=', $id)->count()) {
            $msgReserva = "";
        }

        if ($msgReserva || $msgEmprestimo) {
            return redirect()->to('usuario')->with('erro', $msgEmprestimo, $msgReserva);
        }

        if ($id) {
            Usuario::find($id)->delete();
            return redirect()->to('usuario')->with('sucesso', 'Usuario excluído com sucesso!');
        }
     
        return redirect()->route('usuario');
    }

}


        /*
        $usuario = Usuario::find($id);
        $usuario->delete();
        $registros = Usuario::all();
        return view('usuario.index', compact('registros'));
    }
}
*/