<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Editora;
use App\Livro;
use App\Http\Requests\EditorasRequest;
use Illuminate\Support\Facades\Session;

class EditoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $registros = Editora::all();
        return view('editora.index', compact('registros'));
    }


     
    public function cadastrar()
    {
            return view('editora.cadastrar');

    }  



    /**
     * Show the form for search.
     *
     * @return \Illuminate\Http\Response
     */
    public function search()
    {
        return view('editora');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $camposValidados = $request->validate([
            'nome' => 'required',

            
        ]);
        
        $editora = Editora::create($camposValidados);
        return redirect()->to('editora'); 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

   
 
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editar($id)
    {
       
        $registro = Editora::where('id', '=', $id)->first();
        return view('editora.editar', compact('registro'));
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $camposValidados = $request->validate([
            'nome' => 'required',

        ]);

        $editora = Editora::find($id);
        $editora->fill($camposValidados);
        $editora->save();

        return redirect()->to('editora');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $msgLivro = "";
        
      

        if (Livro::where('editora_id', '=', $id)->count()) {
            $msgLivro = "Não é possível deletar a Editora! Deve está relacionada a um Livro verifique por favor.";
        }



        if ($msgLivro) {
            return redirect()->to('editora')->with('erro', $msgLivro);
        }

        if ($id) {
            Editora::find($id)->delete();
            return redirect()->to('editora')->with('sucesso', 'Editora excluído com sucesso!');
        }
     
        return redirect()->route('editora');
    }

}

        /*
        $editora = Editora::find($id);
        $editora->delete();
        $registros = Editora::all();
        return view('editora.index', compact('registros'));
    }
}
*/

