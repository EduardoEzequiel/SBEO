<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
//use App\Http\Controllers\Auth;
use App\Usuario;
use Session;

class AuthController extends Controller
{

    public function index()
    {
        return view('usuario.login');
    }
    
    public function login(Request $request)
    {
        $dados = $request->only(['login', 'password']);


        if (Auth::attempt($dados)) {
            // Authentication passed...
            return view('bem-vindo')->with('login', 'Login realizado com sucesso!');
        }

        return redirect()->back()->with('erro', 'Erro! Login ou senha incorretos!');
    }

    public function update(UpdateAccount $request)
    {
        $usuario = Auth::user(); // resgata o usuario
    
        $usuario->username = Request::input('username'); // pega o valor do input username
        $usuario->email = Request::input('email'); // pega o valor do input email
    
        if ( ! Request::input('password') == '') // verifica se a senha foi alterada
        {
            $user->password = bcrypt(Request::input('password')); // muda a senha do seu usuario já criptografada pela função bcrypt
        }
    
        $user->save(); // salva o usuario alterado =)
    
        Flash::message('Atualizado com sucesso!');
        return Redirect::to('login.index'); // redireciona pra rota que você achar melhor =)

    }

    public function sair()
    {
        Auth::logout();
        return redirect()->route('login.index');
    }
}
