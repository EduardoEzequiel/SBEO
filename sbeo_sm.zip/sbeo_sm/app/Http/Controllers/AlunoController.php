<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Aluno;
use App\Reserva;
Use App\Emprestimo;
use App\Http\Requests\AlunosRequest;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\Rule;

class AlunoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $registros = Aluno::all();
        return view('aluno.index', compact('registros'));
    }

    public function cadastrar()
    {
            return view('aluno.cadastrar');

    } 

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {     
        $camposValidados = $request->validate([
            'nome' => 'required',
            'matricula'  => ['required', 'unique:aluno,matricula'],
            'ano_letivo' => 'required'

        ]);
        
        $aluno = Aluno::create($camposValidados);
        return redirect()->to('aluno'); 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editar($id)
    {
        $registro = Aluno::where('id', '=', $id)->first();
        return view('aluno.editar', compact('registro'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $unique = Rule::unique('aluno')->ignore($id);

        $camposValidados = $request->validate([
            'nome' => 'required',
            'matricula'  => ['required', $unique], 
            'ano_letivo' => 'required',

        ]);

        $aluno = Aluno::find($id);
        $aluno->fill($camposValidados);
        $aluno->save();

        return redirect()->to('aluno');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {


        $msgEmprestimo = "";
        $msgReserva = "";
        
      

        if (Emprestimo::where('aluno_id', '=', $id)->count()) {
            $msgEmprestimo = "Não é possível deletar o Aluno ! Deve está relacionada a uma Reserva ou Emprestimo verifique por favor.";
        }

        if (Reserva::where('aluno_id', '=', $id)->count()) {
            $msgReserva = "";
        }

        if ($msgReserva || $msgEmprestimo) {
            return redirect()->to('aluno')->with('erro', $msgEmprestimo, $msgReserva);
        }

        if ($id) {
            Aluno::find($id)->delete();
            return redirect()->to('aluno')->with('sucesso', 'Aluno excluído com sucesso!');
        }
     
        return redirect()->route('aluno');
    }

}
        /*
        $aluno = Aluno::find($id);
        $aluno->delete();
        $registros = Aluno::all();
        return view('aluno.index', compact('registros'));
    }
}
*/