<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Emprestimo;
use App\Livro;
use App\Aluno;
use App\Usuario;


class EmprestimoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $registros = Emprestimo::with('livros','usuarios','alunos')->get();;
        return view('emprestimo.index', compact('registros'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $camposValidados = $request->validate([
            'dt_emprestimo' => 'required',
            'dt_devolucao'  => 'required', 
            'livro_id' => 'required',
            'aluno_id' => 'required',
    ]);

        $emprestimo = $request->user()->emprestimos()->create($camposValidados);
        $emprestimo->livros()->decrement('disponibilidade');
        
            
        return redirect()->to('emprestimo'); 
    }

    public function cadastrar()
    {
        $livros  = Livro::where('disponibilidade','>',0)
                                     ->where('situacao','=','ativo')->get();
        
        $usuarios  = Usuario::all();
        $alunos  = Aluno::all();

        return view('emprestimo.cadastrar', compact('livros','usuarios','alunos'));

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function editar($id)
    {   
            $registro = Emprestimo::where('id', '=', $id)->first();
            $livros = Livro::select('*')->orWhere('disponibilidade','>',0)
            ->where('situacao','=','ativo')->get();
            $usuarios = Usuario::all();
            $alunos = Aluno::all();
            return view('emprestimo.editar', compact('registro','livros','usuarios', 'alunos'));
            
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $camposValidados = $request->validate([
            'dt_emprestimo' => 'required',
            'dt_devolucao'  => 'required', 
            'livro_id' => 'required',
            'aluno_id' => 'required',

        ]);

        $emprestimo = Emprestimo::find($id);
        $emprestimo->fill($camposValidados);
        $emprestimo->save();

        return redirect()->to('emprestimo');

       
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $msgEmprestimo = "";
        

        if ($id) {
         Emprestimo::find($id)->delete();
         return redirect()->to('emprestimo')->with('sucesso', 'Emprestimo excluído com sucesso!');
         }
  
      return redirect()->route('emprestimo');
       }

       function CalcularVencimento($data,$dias)
       {
           $novadata = explode("/",$data);
           $dia = $novadata[0];
           $mes = $novadata[1];
           $ano = $novadata[2];
           //PARA DESCOBRIR QUAL DATA SERÁ DAQUI A 5 DIAS
           //echo date('d/m/Y',mktime(0,0,0,$mes,$dia+5,$ano));
           //PARA DESCOBRIR QUAL SERÁ O DIA AMANHÃ
           //echo date('d/m/Y',mktime(0,0,0,$mes,$dia+1,$ano));
           //PARA MÊS QUE VEM
           //echo date('d/m/Y',mktime(0,0,0,$mes + 1,$dia,$ano));
           //PARA ANO QUE VEM
           //echo date('d/m/Y',mktime(0,0,0,$mes,$dia,$ano + 1));
           if ($dias==0)
           {return date('d/m/Y',mktime(0,0,0,$mes,$dia,$ano));}
           else
           {return date('d/m/Y',mktime(0,0,0,$mes,$dia+$dias,$ano));}
       }
    }
