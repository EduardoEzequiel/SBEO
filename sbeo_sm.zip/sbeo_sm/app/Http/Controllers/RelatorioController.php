<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Aluno;
use App\Livro;
use App\Usuario;
use App\Genero;
use App\Editora;
use App\Reserva;
use App\Emprestimo;
use App\Autor;
use Mpdf\Mpdf;
use App\Tickets;

class RelatorioController extends Controller
{
    

   public function index()
        {
            return view('usuario.login');
        }



   public function AlunosRelatorios(Request $request)
    {
        
            $localizar = $request->query('localizar');
            $dataEmissao = Carbon::today();
            $registros =  Aluno::where('nome', 'like', "%{$localizar}%")
            ->orWhere('matricula', 'like', "%{$localizar}%")
            ->orWhere('ano_letivo', 'like', "%{$localizar}%")
                  ->get();
         
           
       return view('relatorio.alunos', compact('dataEmissao', 'registros'));


    }


    public function UsuarioRelatorios(Request $request)
    {
       
        $loca = $request->query('loca');
        $dataEmissao = Carbon::today();
        $registros =  Usuario::where('nome', 'like', "%{$loca}%")
        ->orWhere('matricula', 'like', "%{$loca}%")
        ->orWhere('login', 'like', "%{$loca}%")
              ->get();
     
              
              return view('relatorio.usuario', compact('dataEmissao','registros'));
    }



    public function LivroRelatorios(Request $request)
    {
            $busca = $request->get('busca');  
            $dataEmissao = Carbon::today();
            $registros = Livro::with(['generos','editoras', 'autores'])->when($busca, function ($query) use($busca) {
            $query->whereHas('generos', function($query) use ($busca) {
                $query->where('nome', 'like', "%{$busca}%");
           });    
           $query->orWhereHas('editoras', function($query) use ($busca) {    
                $query->where('nome', 'like', "%{$busca}%");
          });
           $query->orWhereHas('autores', function($query) use ($busca) {     
                $query->where('nome', 'like', "%{$busca}%");
            });
          
        })->get();;
           
           

            return view('relatorio.livro', compact('dataEmissao', 'registros'));
       
    }




    public function EmprestimoRelatorios(Request $request)
    {
            $dataFiltros = $request->only(['initial-date', 'final-date']);
            $dataEmissao = Carbon::today();
            $registros = Emprestimo::with('livros','usuarios','alunos')->when($dataFiltros, function ($query) use($dataFiltros) {
                $query->whereBetween('dt_emprestimo', array_values($dataFiltros));
            })->get();;


            return view('relatorio.emprestimo', compact('dataEmissao', 'registros'));
       
    }

    public function ReservaRelatorios(Request $request)
    {
            $dataFiltros = $request->only(['initial-date', 'final-date']);
            $dataEmissao = Carbon::today();
            $registros = Reserva::with('livros','usuarios','alunos')->when($dataFiltros, function ($query) use($dataFiltros) {
                $query->whereBetween('dt_reserva', array_values($dataFiltros));
            })->get();;

            return view('relatorio.reserva', compact('dataEmissao', 'registros'));
   
   
        }


   
    
    public function LivroInativoRelatorios(Request $request){
           
        $busca = $request->get('busca');  
        $dataEmissao = Carbon::today();
        $registros = Livro::with(['generos','editoras', 'autores'])->where('situacao', 'Inativo')
            ->when($busca, function ($query) use($busca) {
                $query->whereHas('generos', function($query) use ($busca) {
                    $query->where('nome', 'like', "%{$busca}%");
               });    
               $query->orWhereHas('editoras', function($query) use ($busca) {    
                    $query->where('nome', 'like', "%{$busca}%");
              });
               $query->orWhereHas('autores', function($query) use ($busca) {     
                    $query->where('nome', 'like', "%{$busca}%");
                });
              
            })->get();;     
           
            return view('relatorio.livros_inativos', compact('registros'));
       
    }

    public function GerarCarteira($id){
      $dataEmissao = Carbon::today();

      $aluno =  Aluno::where('id', $id)->get();
      $aluno=$aluno[0];
      return view('relatorio.carteira', compact('aluno', 'dataEmissao'));
    }


    public function LivrosPerdidos(Request $request){
        $busca = $request->get('busca');  
        $dataEmissao = Carbon::today();
        $registros = Livro::with(['generos','editoras', 'autores'])->where('status', 'Emprestado')->when($busca, function ($query) use($busca) {
            $query->whereHas('generos', function($query) use ($busca) {
                $query->where('nome', 'like', "%{$busca}%");
           });    
           $query->orWhereHas('editoras', function($query) use ($busca) {    
                $query->where('nome', 'like', "%{$busca}%");
          });
           $query->orWhereHas('autores', function($query) use ($busca) {     
                $query->where('nome', 'like', "%{$busca}%");
            });
          
        })->get();;     
       
        return view('relatorio.livro_perdidos', compact('registros'));
   
    }

    

}
