<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Reserva;
use App\Livro;
use App\Aluno;
use App\Usuario;

class ReservaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $registros = Reserva::with('livros','usuarios','alunos')->get();;
        return view('reserva.index', compact('registros'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $camposValidados = $request->validate([
            'dt_reserva' => 'required',
            'dt_baixa'  => 'required', 
            'livro_id' => 'required',
            'aluno_id' => 'required',

        ]);

        $reserva = $request->user()->reservas()->create($camposValidados);
        $reserva->livros()->decrement('disponibilidade');
      //  $reserva = Reserva::create($camposValidados);
        
            
        return redirect()->to('reserva'); 
    }

    public function cadastrar()
    {
        $livros  = Livro::select('*')->where('disponibilidade','>',0)
                                ->where('situacao','=','ativo')->get();
                       

        $usuarios  = Usuario::all();
        $alunos  = Aluno::all();

        return view('reserva.cadastrar', compact('livros','usuarios','alunos'));

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editar($id)
    {   
            $registro = Reserva::where('id', '=', $id)->first();
            $livros = Livro::select('*')->orWhere('disponibilidade','>',0)
            ->where('situacao','=','ativo')->get();
            $usuarios = Usuario::all();
            $alunos = Aluno::all();
            return view('reserva.editar', compact('registro','livros','usuarios', 'alunos'));
            
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $camposValidados = $request->validate([
            'dt_reserva' => 'required',
            'dt_baixa'  => 'required', 
            'livro_id' => 'required',
            'aluno_id' => 'required',

        ]);

        $reserva = Reserva::find($id);
        $reserva->fill($camposValidados);
        $reserva->save();

        return redirect()->to('reserva');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
    /*
        $reserva = Reserva::find($id);
        $reserva->delete();
        $registros = Reserva::all();
        return view('reserva.index', compact('registros'));
 */

      $msgReserva = "";
        

      if ($id) {
       Reserva::find($id)->delete();
       return redirect()->to('reserva')->with('sucesso', 'Reserva excluído com sucesso!');
       }

    return redirect()->route('reserva');
     }
    }



