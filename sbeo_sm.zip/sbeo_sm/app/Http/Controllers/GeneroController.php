<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Genero;
use App\Subgenero;
use App\Livro;
use App\Http\Requests\GenerosRequest;
use Illuminate\Support\Facades\Session;

class GeneroController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       
        $registros = Genero::with(['subgeneros'])->get();;
       // dd($registros);
        return view('genero.index', compact('registros'));


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $camposValidados = $request->validate([
            'nome' => 'required',
            'cor'  => 'required', 
            'subgeneros' => 'required',

        ]);

        $genero = Genero::create($camposValidados);
        $genero->subgeneros()->attach($request->get('subgeneros'));

            
        return redirect()->to('genero');
    }

    public function cadastrar()
    {
            $subgeneros  = Subgenero::all();
            $registro = new Genero();
            return view('genero.cadastrar', compact('subgeneros','registro'));

    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editar($id)
    {   
            $registro = Genero::with('subgeneros')->find($id);
            $subgeneros = Subgenero::all();
            return view('genero.editar', compact('registro','subgeneros'));
            
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $camposValidados = $request->validate([
            'nome' => 'required',
            'cor' => 'required',
            'subgeneros' => 'required',
          

        ]);

        $genero = Genero::find($id);
        $genero->fill($camposValidados);
        $genero->save();

        $genero->subgeneros()->sync($request->get('subgeneros'));
        return redirect()->to('genero');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      

        $msgLivro = "";
        
      

        if (Livro::where('genero_id', '=', $id)->count()) {
            $msgLivro = "Não é possível deletar o Genero ! Deve está relacionada a um Livro verifique por favor.";
        }



        if ($msgLivro) {
            return redirect()->to('genero')->with('erro', $msgLivro);
        }

        if ($id) {
            Genero::find($id)->delete();
            return redirect()->to('genero')->with('sucesso', 'Editora excluído com sucesso!');
        }
     
        return redirect()->route('genero');
    }

}
        /*
        $genero = Genero::find($id);
        $genero->delete();
        return redirect()->to('genero'); 
       
    }
}
*/