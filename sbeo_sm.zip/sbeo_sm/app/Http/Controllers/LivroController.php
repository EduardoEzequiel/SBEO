<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Genero;
use App\Livro;
use App\Editora;
use App\Subgenero;
use App\Autor;
use App\Emprestimo;
use App\Reserva;
use App\Http\Requests\LivrosRequest;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\Rule;

class LivroController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $registros = Livro::with(['generos','editoras', 'autores'])->get();;
        return view('livro.index', compact('registros'));
          
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $camposValidados = $request->validate([
            'nome' => 'required|unique:livro',
            'ano'  => 'required|integer', 
            'numeracao' => 'required|unique:livro',
            'status' => 'required',
            'isbn' => 'required|unique:livro',
            'disponibilidade' => 'required',
            'localizacao' => 'required',
            'situacao' => 'required',
            'volume' => 'required',
            'tipo' => 'required',
            'genero_id' => 'required',
            'editora_id' => 'required',
            'autores' => 'required',

        ]);

        $livro = Livro::create($camposValidados);
        $livro->autores()->attach($request->get('autores'));
            
        return redirect()->to('livro');  
    }
    


    public function cadastrar()
    {
        $generos  = Genero::all();
        $editoras  = Editora::all();
        $autores = Autor::all();
        $registro = new Livro();
        return view('livro.cadastrar', compact('generos','editoras', 'autores', 'registro'));

    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editar($id)
    {   
            

            $registro = Livro::with('autores')->find($id);
            $generos = Genero::all();
            $editoras = Editora::all();
            $autores = Autor::all();
            return view('livro.editar', compact('registro','generos','editoras', 'autores'));
            
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $unique = Rule::unique('livro')->ignore($id);

        $camposValidados = $request->validate([
            'nome' => 'required',
            'ano'  => 'required|integer', 
            'numeracao' => ['required', $unique],
            'status' => 'required',
            'isbn' => ['required', $unique],
            'disponibilidade' => 'required',
            'localizacao' => 'required',
            'situacao' => 'required',
            'volume' => 'required',
            'tipo' => 'required',
            'genero_id' => 'required',
            'editora_id' => 'required',
            'autores' => 'required',
        ]);

        $livro = Livro::find($id);
        $livro->fill($camposValidados);
        $livro->save();

        $livro->autores()->sync($request->get('autores'));


        return redirect()->to('livro');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
            $msgEmprestimo = "";
            $msgReserva = "";
          

            if (Emprestimo::where('livro_id', '=', $id)->count()) {
                $msgEmprestimo = "Não é possível deletar o Livro! Esse Livro está relacionado a um Emprestimo ou Reserva verifique por favor.";
            }

            if (Reserva::where('livro_id', '=', $id)->count()) {
                $msgReserva = "";
            }

            

            if ($msgEmprestimo || $msgReserva ) {
                return redirect()->to('livro')->with('erro', $msgEmprestimo . $msgReserva);
            }

            if ($id) {
                Livro::find($id)->delete();
                return redirect()->to('livro')->with('sucesso', 'Livro excluído com sucesso!');
            }
         
            return redirect()->route('livro');
        }

    }

        /*
        $livro = Livro::find($id);
        $livro->delete();
        return redirect()->to('livro'); 
       */
    

