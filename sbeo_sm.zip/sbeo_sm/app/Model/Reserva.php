<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reserva extends Model
{
    protected $fillable = ['dt_reserva','dt_baixa','livro_id','usuario_id','aluno_id'];
    protected $guarded = ['id'];
    protected $table = 'reserva';
    protected $dates = ['dt_reserva', 'dt_baixa'];
    public $timestamps = false;


    public function livros()
    {
    	return $this->belongsTo(Livro::class, 'livro_id');
    }

    public function usuarios()
    {
    	return $this->belongsTo(Usuario::class, 'usuario_id');
    }

    public function alunos()
    {
    	return $this->belongsTo(Aluno::class, 'aluno_id');
    }
  
    public function setDtReservaAttribute($value)
    {
        $this->attributes['dt_reserva'] = \Carbon\Carbon::createFromFormat('d/m/Y', $value);
    }


    public function setDtBaixaAttribute($value)
    {
        $this->attributes['dt_baixa'] = \Carbon\Carbon::createFromFormat('d/m/Y', $value);
    }

}
