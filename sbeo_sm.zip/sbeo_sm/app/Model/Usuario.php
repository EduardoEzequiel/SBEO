<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Usuario extends Authenticatable
{
    protected $fillable = ['nome','matricula','login','password','perfil','remember_token' ];
    protected $guarded = ['id'];
    protected $table = 'usuario';
    public $timestamps = false;
    

    public function emprestimos()
    {
    	return $this->hasMany(Emprestimo::class, 'usuario_id');
    }

    public function reservas()
    {
    	return $this->hasMany(Reserva::class, 'usuario_id');
    }

}
