<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Editora extends Model
{
    protected $fillable = ['nome'];
    protected $guarded = ['id'];
    protected $table = 'editora';
    public $timestamps = false;
}
