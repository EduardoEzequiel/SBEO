<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Autor extends Model
{
    protected $fillable = [
        'nome'
    ];
    protected $guarded = ['id'];
    protected $table = 'autor';
    public $timestamps = false;
    
   public function livros(){
        return $this->belongsToMany(Livro::class);
    }
}
