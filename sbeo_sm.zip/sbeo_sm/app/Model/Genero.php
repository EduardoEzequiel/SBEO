<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Genero extends Model
{
    protected $fillable = ['nome','cor','subgenero_id'];
    protected $guarded = ['id'];
    protected $table = 'genero';
    public $timestamps = false;


    public function subgeneros(){
        return $this->belongsToMany(Subgenero::class);
    }
}
