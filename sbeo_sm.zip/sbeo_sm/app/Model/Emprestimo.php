<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Emprestimo extends Model
{
    protected $fillable = ['dt_emprestimo','dt_devolucao','livro_id','usuario_id','aluno_id'];
    protected $guarded = ['id'];
    protected $table = 'emprestimo';
    protected $dates = ['dt_emprestimo', 'dt_devolucao'];
    public $timestamps = false;


    public function livros()
    {
    	return $this->belongsTo(Livro::class, 'livro_id');
    }

    public function usuarios()
    {
    	return $this->belongsTo(Usuario::class, 'usuario_id');
    }

    public function alunos()
    {
    	return $this->belongsTo(Aluno::class, 'aluno_id');
    }

    public function setDtEmprestimoAttribute($value)
    {
        $this->attributes['dt_emprestimo'] = \Carbon\Carbon::createFromFormat('d/m/Y', $value);
    }


    public function setDtDevolucaoAttribute($value)
    {
        $this->attributes['dt_devolucao'] = \Carbon\Carbon::createFromFormat('d/m/Y', $value);
    }

    

}
