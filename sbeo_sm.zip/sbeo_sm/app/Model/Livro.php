<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Livro extends Model
{
    protected $fillable = [
        'nome','numeracao','status','ano','isbn','disponibilidade',
        'localizacao','situacao','volume','tipo','genero_id','editora_id'
    ];
    protected $guarded = ['id'];
    protected $table = 'livro';
    public $timestamps = false;

    public function autores(){
        return $this->belongsToMany(Autor::class);
    }

    public function generos()
    {
    	return $this->belongsTo(Genero::class, 'genero_id');
    }

    public function editoras()
    {
    	return $this->belongsTo(Editora::class, 'editora_id');
    }

}
