<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Subgenero extends Model
{
    protected $fillable = ['nome'];
    protected $guarded = ['id'];
    protected $table = 'subgenero';
    public $timestamps = false;

    public function geneross(){
        return $this->belongsToMany(Genero::class);
    }
}
