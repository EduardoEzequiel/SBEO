<?php
header('location:/sbeo/public');
?>
