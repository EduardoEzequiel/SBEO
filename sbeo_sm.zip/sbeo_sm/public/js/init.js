$(document).ready(function() {
  //DataTable
  $("#datatable").DataTable({"language": {
            
    "sEmptyTable": "Nenhum registro encontrado",
    "sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
    "sInfoEmpty": "Mostrando 0 até 0 de 0 registros",
    "sInfoFiltered": "(Filtrados de _MAX_ registros)",
    "sInfoPostFix": "",
    "sInfoThousands": ".",
    "sLengthMenu": "_MENU_ Resultados por página",
    "sLoadingRecords": "Carregando...",
    "sProcessing": "Processando...",
    "sZeroRecords": "Nenhum registro encontrado",
    "sSearch": "Pesquisar",
    "oPaginate": {
        "sNext": "Próximo",
        "sPrevious": "Anterior",
        "sFirst": "Primeiro",
        "sLast": "Último"
    },
    "oAria": {
        "sSortAscending": ": Ordenar colunas de forma ascendente",
        "sSortDescending": ": Ordenar colunas de forma descendente"
    }

        }});

  //datepicker
  $(".datapicker").datepicker({
    format: "dd/mm/yyyy",
    autoclose: true
  });

  //select com pesquisa
  $(".select").select2({
    "language": {
       "noResults": function(){
           return "Nenhum Resultado Encontrado";
       }
   },
  });

  //Máscara de telefone
  $("#telefone").inputmask({
    mask: "(99) 9999-9999"
  });

  //bootstrap WYSIHTML5 - text editor
  $(".textarea").wysihtml5();

  //iCheck for checkbox and radio inputs
  $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
    checkboxClass: "icheckbox_minimal-blue",
    radioClass: "iradio_minimal-blue"
  });

  //Red color scheme for iCheck
  $(
    'input[type="checkbox"].minimal-red, input[type="radio"].minimal-red'
  ).iCheck({
    checkboxClass: "icheckbox_minimal-red",
    radioClass: "iradio_minimal-red"
  });

  //Flat red color scheme for iCheck
  $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
    checkboxClass: "icheckbox_flat-green",
    radioClass: "iradio_flat-green"
  });

  //iniciarlizar o tooltip utilizado na imagem da grade curricular
  $('[data-toggle="tooltip"]').tooltip();
});

function printDiv(divName) {
  var printContents = document.getElementById(divName).innerHTML;
  var originalContents = document.body.innerHTML;

  document.body.innerHTML = printContents;

  window.print();

  document.body.innerHTML = originalContents;
}